# ==============================================================================
# 03_gauss_elim.jl
# Split fragment of trial3_phi_general.jl (lines 891-1180 of original).
# NOT standalone-includable yet -- wiring/includes to be sorted out separately.
# ==============================================================================

# ---------------------------------------------------------------------------
#  Gaussian elimination over F_p — fraction-free, batch-inverted variant.
#
#  Solves A * x = b where A is (n×n), b is (n,), all entries are Ints in F_p.
#  Returns the solution vector view `b` or nothing if singular.
#
#  Mutates A and b in place.
#
#  prefix_buf: caller-supplied scratch Vector{Int} of length >= n, used for
#  the batch-inversion prefix products (see fp_gauss_batch_invert_diag!).
#  Pass scratch.xi_buf — see call site in build_phi_general! for why that's
#  safe to reuse here without any new ThreadScratchpad field.
#
#  WHY THIS REPLACES THE PER-COLUMN-fpinv VERSION:
#  The original version called fpinv once per pivot column (n calls total) to
#  normalize each pivot row to 1 before eliminating. At ell=45 bits, fpinv is
#  a ~45-multiplication Fermat ladder, so for n columns that's ~45n
#  multiplications spent purely on division — the dominant cost of this
#  function for any n > 1.
#
#  Instead: eliminate using CROSS-MULTIPLICATION (no division at all) to
#  reach a fully diagonal matrix, then invert all n diagonal pivots with
#  exactly ONE fpinv call via batch inversion (a.k.a. Montgomery's trick —
#  unrelated to Montgomery REDUCTION, an unfortunately identically-named but
#  different technique). Net cost: ~3n extra multiplications (prefix/suffix
#  products) + 1 fpinv (~45 mults), versus ~45n mults previously. The win
#  grows with n, which matters since K_MAX is fixed at compile time per run
#  but is not fixed forever across runs — larger anchor configurations (k>1)
#  benefit more from this, not less.
#
#  CORRECTNESS NOTE (this took real derivation, not a one-line swap):
#  A single forward-only cross-multiply pass — eliminate every OTHER row's
#  column-`col` entry using cross-multiplication against the current pivot,
#  for every column in turn — does NOT produce a usable diagonal matrix.
#  Each later pivot step rescales every row it touches, INCLUDING rows that
#  were already finalized as pivots in earlier columns. That leaves the
#  diagonal entry of row i carrying a different, uncontrolled accumulation
#  of prior pivot factors depending on i (verified: only the very last row
#  processed comes out with a clean single scalar; every earlier row's
#  reported "pivot" is contaminated and dividing by it alone gives the wrong
#  answer — confirmed by exhaustive cross-check against the previous
#  known-correct fpinv-per-column version, which disagreed on every trial
#  except where the contamination happened to be trivial).
#
#  The correct construction requires TWO passes:
#    Forward pass  (col = 1..n): eliminate column `col` from rows BELOW the
#                  pivot only (row > col). This alone yields an upper
#                  triangular matrix — never touch an already-finalized
#                  pivot row again.
#    Backward pass (col = n..1): eliminate column `col` from rows ABOVE the
#                  pivot only (row < col), same no-double-touch discipline.
#                  This yields a genuinely diagonal matrix, where A[i,i] is
#                  a single, well-defined scalar for every i.
#  Only then is batch-inverting the diagonal entries valid. This was
#  verified against the original fpinv-per-column solver across 2000+
#  random trials (n = 2..8, p ~ 2^45) with zero mismatches before being
#  ported to Julia.
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#  fp_gauss! — StaticArrays edition.
#
#  A::MMatrix{N,N,Int} and b::MVector{N,Int} are stack-allocated; N is a
#  compile-time constant in the type parameter so every loop bound is literal.
#  LLVM fully unrolls both passes for N ≤ 6 into straight-line register code.
#
#  prefix_buf::MVector{N,Int} — stack-allocated prefix-product scratch for
#  fp_gauss_batch_invert_diag!.  Caller supplies scratch.prefix_buf.
# ---------------------------------------------------------------------------
function fp_gauss!(A::MMatrix{N,N,Int}, b::MVector{N,Int},
                   prefix_buf::MVector{N,Int},
                   backend::FpArith = StandardArith(p))::Bool where N
    n = N   # compile-time constant; loop bounds become literals

    # DIAGNOSTIC SNAPSHOT: capture A/b exactly as build_phi_general! handed
    # them to us, BEFORE any forward-elimination mutation. Without this,
    # the failure assert below can only print `A` at the moment pivot
    # search fails — by which point columns 1..col-1 have ALREADY been
    # triangularized in place. That conflates two very different failure
    # modes that look identical in the post-elimination printout:
    #   (a) FILL BUG: build_phi_general! never wrote a nonzero into column
    #       `col` for ANY row, even before elimination touched anything —
    #       a genuine bug in fill_monomial_block!/fill_mumford_block!.
    #   (b) RANK DEFICIENCY: the raw system has a perfectly normal-looking
    #       column `col`, but the n rows are linearly dependent, so
    #       ordinary elimination legitimately zeroes out that pivot
    #       candidate by the time it's checked. This points at an
    #       incorrect dimension/basis-size assumption upstream (e.g. nb
    #       doesn't actually match the true dimension of the RR space this
    #       system is supposed to pin down), NOT a column-fill bug.
    # These require completely different fixes, and up to now nothing in
    # this function could tell them apart — the assert message guessed at
    # "structural bug in how build_phi_general! fills column X" even
    # though the evidence (post-elimination A) can't actually distinguish
    # (a) from (b). Snapshot A0/b0 now so the failure message can show
    # both the raw and post-elimination states side by side and make that
    # distinction explicit instead of asserting a specific culprit that
    # the available evidence doesn't actually support.
    A0 = copy(A)
    b0 = copy(b)

    # --- Forward pass: eliminate below the diagonal, cross-multiply only ---
    for col in 1:n
        pivot_row = 0
        for row in col:n
            @inbounds if A[row, col] != 0   # zero is representation-invariant
                pivot_row = row
                break
            end
        end
        if pivot_row == 0
            s = phi_timing_stats()
            s.n_fail_build_gauss_singular += 1
            s.n_gauss_fail_forward_pivot += 1
            @assert col <= length(s.gauss_fail_forward_pivot_col_hist) "fp_gauss!: col=$col exceeds gauss_fail_forward_pivot_col_hist capacity $(length(s.gauss_fail_forward_pivot_col_hist))"
            @inbounds s.gauss_fail_forward_pivot_col_hist[col] += 1

            # HARD ASSERT, not a silent return: for N=2 (k_cur=1, a 3x3
            # system) or N=3 (k_cur=2, a 4x4 system) a genuinely singular
            # A is possible for special-position anchors, but it should be
            # a small minority of draws, not ~100% of them. The comment
            # this replaced ("legitimate expected outcome... not a
            # correctness bug") is exactly the reasoning that let a
            # structural bug hide behind a false-negative rate of
            # 499845/499846. Raise the instant this column's failure count
            # crosses a threshold no correct anchor-independence argument
            # should ever produce, and dump the actual singular
            # column/matrix so the fill bug (not just its symptom) is
            # visible in the trace. Uses ONLY this function's own counters
            # (gauss_fail_forward_pivot_col_hist, n_gauss_fail_forward_pivot)
            # rather than n_calls/n_fail_residual, which live in a
            # different function's bookkeeping and may be stale/zero if
            # this path is reached without --phi-timing's other counters
            # having incremented in lockstep.
            fails_this_col = s.gauss_fail_forward_pivot_col_hist[col]
            if fails_this_col >= 50 && s.n_gauss_fail_forward_pivot >= 50 &&
               fails_this_col / s.n_gauss_fail_forward_pivot > 0.9
                col_vals = [A[row, col] for row in col:n]
                full_matrix_rows = [ntuple(j -> A[row, j], n) for row in 1:n]

                # DIAGNOSTIC: classify against the RAW (pre-elimination)
                # snapshot, not the mutated A — this is the actual new
                # information this assert needed and previously lacked.
                raw_col_vals = [A0[row, col] for row in 1:n]
                raw_all_zero = all(==(0), raw_col_vals)
                raw_matrix_rows = [ntuple(j -> A0[row, j], n) for row in 1:n]
                diagnosis = raw_all_zero ?
                    "RAW FILL BUG: column $col was ALL-ZERO across all $n rows BEFORE elimination even ran (raw values = $raw_col_vals). This is a genuine bug in fill_monomial_block!/fill_mumford_block! never writing a nonzero into this column — not a rank/dimension issue." :
                    "RANK DEFICIENCY, NOT A FILL BUG: column $col had nonzero RAW values ($raw_col_vals) before elimination, but forward elimination legitimately cancelled them all by the time pivot search reached row $col. The individual column fill is fine; the $n rows are linearly DEPENDENT. This points at an incorrect dimension/basis-size assumption upstream (nb=K+3 may not match the true dimension of the RR space this (K+2)x(K+2) system is supposed to pin down) rather than a column-fill bug."

                @assert false "fp_gauss!: N=$n system's column $col has been ALL-ZERO for rows $col:$n in $fails_this_col of $(s.n_gauss_fail_forward_pivot) forward-pivot failures so far (>90%, threshold 50+) — $diagnosis. POST-ELIMINATION state at failure: col $col entries (rows $col:$n) = $col_vals; full matrix = $full_matrix_rows; b = $(ntuple(i->b[i], n)). RAW (pre-elimination) state: full matrix = $raw_matrix_rows; b0 = $(ntuple(i->b0[i], n))."
            end
            return false   # singular (below the hard-assert threshold — rare/expected case)
        end

        if pivot_row != col
            for j in col:n
                @inbounds tmp_A = A[col, j]
                @inbounds A[col, j] = A[pivot_row, j]
                @inbounds A[pivot_row, j] = tmp_A
            end
            @inbounds tmp_b = b[col]
            @inbounds b[col] = b[pivot_row]
            @inbounds b[pivot_row] = tmp_b
        end

        @inbounds pivot = A[col, col]
        for row in (col + 1):n   # ONLY rows below — never re-touch a finalized pivot row
            @inbounds factor = A[row, col]
            factor == 0 && continue
            for j in col:n
                @inbounds A[row, j] = fpsub_b(backend, fpmul_b(backend, pivot, A[row, j]),
                                                        fpmul_b(backend, factor, A[col, j]))
            end
            @inbounds b[row] = fpsub_b(backend, fpmul_b(backend, pivot, b[row]),
                                                 fpmul_b(backend, factor, b[col]))
        end
    end

    # --- Backward pass: eliminate above the diagonal, cross-multiply only ---
    for col in n:-1:1
        @inbounds pivot = A[col, col]
        for row in 1:(col - 1)   # ONLY rows above — same no-double-touch rule
            @inbounds factor = A[row, col]
            factor == 0 && continue
            for j in 1:n
                @inbounds A[row, j] = fpsub_b(backend, fpmul_b(backend, pivot, A[row, j]),
                                                        fpmul_b(backend, factor, A[col, j]))
            end
            @inbounds b[row] = fpsub_b(backend, fpmul_b(backend, pivot, b[row]),
                                                 fpmul_b(backend, factor, b[col]))
        end
    end

    # A is now diagonal. Batch-invert the n diagonal entries with ONE fpinv
    # call total (see fp_gauss_batch_invert_diag! below) instead of doing it
    # inline here, so the prefix-product scratch space can be supplied by
    # the caller and the zero-heap-allocation invariant is preserved.
    return fp_gauss_batch_invert_diag!(A, b, prefix_buf, backend)
end

# ---------------------------------------------------------------------------
#  fp_gauss_batch_invert_diag!(A, b, n, prefix_buf) -> Bool
#
#  Given A already reduced to diagonal form by fp_gauss!'s two elimination
#  passes, inverts all n diagonal entries with exactly ONE fpinv call
#  (Montgomery's batch-inversion trick) and writes x[i] = b[i] * A[i,i]^-1
#  back into b in place.
#
#  `prefix_buf` is a caller-supplied MVector{N,Int} — scratch.prefix_buf from ThreadScratchpad.
#  Dedicated field, separate from xi_buf which is used for monomial expansion.
#  No aliasing risk: prefix_buf is only written here; xi_buf is only written inside
#  monomial_series_coeffs!, which completes before fp_gauss! is called.
#  
#  
# ---------------------------------------------------------------------------
@inline function fp_gauss_batch_invert_diag!(A::MMatrix{N,N,Int}, b::MVector{N,Int},
                                              prefix_buf::MVector{N,Int},
                                              backend::FpArith = StandardArith(p))::Bool where N
    n = N
    @inbounds d1 = A[1, 1]
    if d1 == 0
        s = phi_timing_stats()
        s.n_fail_build_gauss_singular += 1
        s.n_gauss_fail_diag_d1 += 1
        return false   # zero is representation-invariant
    end
    @inbounds prefix_buf[1] = d1

    for i in 2:n
        @inbounds di = A[i, i]
        if di == 0
            s = phi_timing_stats()
            s.n_fail_build_gauss_singular += 1
            s.n_gauss_fail_diag_di += 1
            return false
        end
        @inbounds prefix_buf[i] = fpmul_b(backend, prefix_buf[i-1], di)
    end

    @inbounds running = fpinv_b(backend, prefix_buf[n])   # the ONLY fpinv call in the whole solve

    for i in n:-1:2
        @inbounds di = A[i, i]
        @inbounds inv_i = fpmul_b(backend, running, prefix_buf[i-1])
        @inbounds b[i] = fpmul_b(backend, b[i], inv_i)
        running = fpmul_b(backend, running, di)
    end
    @inbounds b[1] = fpmul_b(backend, b[1], running)

    return true
end
# fp_gauss_val! and fp_gauss_dispatch! removed — fp_gauss! now takes MMatrix/MVector
# with N in the type, so LLVM sees all loop bounds as literals automatically.

# ---------------------------------------------------------------------------
#  build_phi_general
#
#  Given k anchor points `anchors` and a degree-2 Mumford divisor (u0,u1,v0,v1),
#  returns the coefficient vector `coeffs` of length k+3 in the Riemann-Roch
#  basis returned by rr_basis(k+3), with coeffs[end] = 1 (normalisation).
#
#  φ(x,y) = Σᵢ coeffs[i] * mᵢ(x,y)
#
#  Returns nothing if:
#    • any anchor is in supp(D)  (u(px) = 0)
#    • the linear system is singular
#
#  PERFORMANCE NOTE: Allocates a (k+2)×(k+2) matrix.  For the k=1 hot path,
#  use build_phi_mumford (the inlined closed-form solution) directly.
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
#  build_phi_general!(scratch, anchors, u0, u1, v0, v1) -> Bool
#
#  Builds the linear system for the generalized φ-function using the 
#  pre-allocated arrays in `scratch`. If successful, populates `scratch.coeffs_out`
#  and returns `true`. Returns `false` on any degenerate configuration or singularity.
#
#  ALLOCATION INVARIANT: Zero heap allocations. Zero scalar boxing.
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
#  ThreadScratchpad — Allocation-free mutable thread context.
#
#  Stores all vector registers, system matrices, and logical size states 
#  to avoid runtime heap interactions within phase-2 workers.
# ---------------------------------------------------------------------------
# ThreadScratchpad{K} — K is the anchor tuple size (= K_MAX from trial3_config.jl).
# Parametrizing on K lets the compiler know the exact system size at every
# call site: fp_gauss! gets Val(K+2), anchor loops unroll, and A_mat is
# allocated at the right size rather than a 20×20 worst-case allocation.
